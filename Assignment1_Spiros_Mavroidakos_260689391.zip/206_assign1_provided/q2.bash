#!/bin/bash

count="$1"  # stores the digit entere by the user
i=0 	    # counter to open a specific amount of panes
k=1	    # used below with the cut command to get the name of the picture to open
eogCount=0  # the amount of eog instances

name="" # used with the cut command and stores the name of the picture to open
ls *.jpg > new # saves all the picture names to a file
name=$(cut -d$'\n' -f1 new &) # gets the name ofthe first picture to open

while true; 
do

while [ $i -lt $count ]; 
do
	eog -n  "$name" & # opens the instance of eog
	let k=k+1 #increments variables 
	let i=i+1
	name=$(cut -d$'\n' -f"$k" new &) #gets the new name of the picture to open
	if [ $k -gt 8 ] #checks to see if all the pictures have been cycled through and makes adjustments
	then
		let k=1
		name=$(cut -d$'\n' -f"$k" new &)
	fi
done
	eogCount=$(ps | grep eog | wc -l) #gets the amount of eog instances open
	if [ $eogCount -lt $count ] ; # updates visuals if a pane is closed 
	then
		let i=i-1
	fi		

done
