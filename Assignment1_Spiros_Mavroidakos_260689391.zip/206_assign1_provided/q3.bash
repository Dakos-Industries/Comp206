#!/bin/bash
name=" " #will hold the name of a file when using convert-append
COMMAND="$1" #gets the command from the command line
touch result.jpg # this just makes sure that the result.jpg file is empty initially
rm result.jpg
touch result.jpg
if [ $COMMAND = "alpha" ] #start the alpha command
then

	ls *.dat > alpha #makes a list of picture names

	sed -i 's/.dat//g' alpha #removes file extension

	sort alpha #sorts the file contents

	cat *.dat > data # puts data into a file
	ls *.jpg > alpha #gets picture names and saves them to a file 
	sed -n '/result.jpg/!p' alpha > temp #makes sure that only the animals are in the file
	paste -d" " temp data > newfile #fuses the names and data
 	
	sort -r newfile > new #sorts them as done before
	awk -F" " '{print $1}' new > newfile #makes sure that only the filenames remain 

	i=0
	while [ $i -lt 8 ] #loop to make the appended picture
	do
		let i=i+1
		name=$(cut -d$'\n' -f"$i" newfile &)
		convert $name result.jpg -append  result.jpg

 		
	done 
	


	rm alpha new newfile data temp #some cleanup. deletes temp files
fi   

if [ $COMMAND = "weight" ] #same procedure as the alpha command
then 

	ls *.dat > weight
	sed -i 's/.dat//g' weight
	
	cat *.dat > data
	paste -d" " weight data > names_data
	
	sort -k2n names_data | awk -F" " '{print $1}'

	ls *.jpg > weight
	sed -n '/result.jpg/!p' weight > temp 
	paste -d" " temp data > newfile
 	
	sort -k2nr newfile > new
	awk -F" " '{print $1}' new > newfile

	i=0
	while [ $i -lt 8 ]
	do
		let i=i+1
		name=$(cut -d$'\n' -f"$i" newfile &)
		convert $name result.jpg -append  result.jpg

 		
	done 
	
	rm weight data new names_data newfile temp
fi

if [ $COMMAND = "length" ] #same procedure as the alpha command 
then 

	ls *.dat > length
	sed -i 's/.dat//g' length
	
	cat *.dat > data
	paste -d" " length data > names_data
	
	sort -k3n names_data | awk -F" " '{print $1}' 

	ls *.jpg > length
	sed -n '/result.jpg/!p' length > temp
	paste -d" " temp data > newfile
 	
	sort -k3nr newfile > new

	awk -F" " '{print $1}' new > newfile
	i=0
	while [ $i -lt 8 ]
	do
		let i=i+1
		name=$(cut -d$'\n' -f"$i" newfile &)
		convert $name result.jpg -append  result.jpg

 		
	done 
	
	
	rm length data names_data newfile new temp
fi
